/* ============================================================
 *  ระบบวางบิล & เก็บเงิน (Billing & Payment System)
 *  Backend: Express + better-sqlite3
 *  ------------------------------------------------------------
 *  ฟีเจอร์:
 *   1. สร้างเอกสารใบวางบิลอัตโนมัติ (auto invoice no.)
 *   2. ใบเสร็จรับเงิน (auto receipt no.)
 *   3. จัดการฐานข้อมูลลูกค้า
 *   4. ตรวจสอบสถานะการชำระเงิน
 *   5. แจ้งเตือน/ติดตามเมื่อถึงกำหนดชำระ
 *   6. สถานะการชำระ: รอชำระ / ชำระแล้ว / ค้างชำระ
 *   7. ส่งเอกสารผ่านอีเมล หรือ SMS ได้ทันที
 *   8. รายงาน & Dashboard สรุปยอดขาย รายรับ รายวัน/รายเดือน
 * ============================================================ */

const express = require('express');
const session = require('express-session');
const bcrypt = require('bcryptjs');
const Database = require('better-sqlite3');
const path = require('path');

// nodemailer เป็น optional — ถ้าไม่ได้ติดตั้งหรือไม่ได้ตั้งค่า SMTP
// ระบบจะทำงานในโหมด "จำลองการส่ง" (simulated) แทน
let nodemailer = null;
try { nodemailer = require('nodemailer'); } catch (_) { /* optional */ }

const app = express();
const db = new Database(path.join(__dirname, 'billing.db'));
db.pragma('journal_mode = WAL');

/* ─────────────────────────────────────────────────────────────
 *  SCHEMA
 * ───────────────────────────────────────────────────────────── */
db.exec(`
  CREATE TABLE IF NOT EXISTS admins (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    username TEXT UNIQUE NOT NULL,
    password TEXT NOT NULL,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP
  );

  CREATE TABLE IF NOT EXISTS settings (
    key TEXT PRIMARY KEY,
    value TEXT
  );

  CREATE TABLE IF NOT EXISTS customers (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    code TEXT UNIQUE,
    name TEXT NOT NULL,
    contact_name TEXT,
    phone TEXT,
    email TEXT,
    address TEXT,
    tax_id TEXT,
    note TEXT,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP
  );

  CREATE TABLE IF NOT EXISTS invoices (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    invoice_no TEXT UNIQUE NOT NULL,
    customer_id INTEGER NOT NULL,
    issue_date TEXT NOT NULL,
    due_date TEXT NOT NULL,
    status TEXT NOT NULL DEFAULT 'pending',     -- pending | paid | overdue
    subtotal REAL NOT NULL DEFAULT 0,
    discount REAL NOT NULL DEFAULT 0,
    tax_rate REAL NOT NULL DEFAULT 0,
    tax_amount REAL NOT NULL DEFAULT 0,
    total REAL NOT NULL DEFAULT 0,
    paid_amount REAL NOT NULL DEFAULT 0,
    note TEXT,
    paid_at DATETIME,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (customer_id) REFERENCES customers(id)
  );

  CREATE TABLE IF NOT EXISTS invoice_items (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    invoice_id INTEGER NOT NULL,
    description TEXT NOT NULL,
    quantity REAL NOT NULL DEFAULT 1,
    unit_price REAL NOT NULL DEFAULT 0,
    amount REAL NOT NULL DEFAULT 0,
    FOREIGN KEY (invoice_id) REFERENCES invoices(id) ON DELETE CASCADE
  );

  CREATE TABLE IF NOT EXISTS payments (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    receipt_no TEXT UNIQUE NOT NULL,
    invoice_id INTEGER NOT NULL,
    amount REAL NOT NULL,
    method TEXT,
    paid_date TEXT NOT NULL,
    note TEXT,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (invoice_id) REFERENCES invoices(id) ON DELETE CASCADE
  );

  CREATE TABLE IF NOT EXISTS notifications (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    invoice_id INTEGER,
    channel TEXT,            -- email | sms
    doc_type TEXT,           -- invoice | receipt | reminder
    recipient TEXT,
    subject TEXT,
    message TEXT,
    status TEXT,             -- sent | simulated | failed
    error TEXT,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (invoice_id) REFERENCES invoices(id) ON DELETE CASCADE
  );
`);

/* ─── seed admin (admin / admin1234) ─── */
if (!db.prepare('SELECT id FROM admins WHERE username = ?').get('admin')) {
  db.prepare('INSERT INTO admins (username, password) VALUES (?, ?)')
    .run('admin', bcrypt.hashSync('admin1234', 10));
  console.log('✅ สร้าง admin เริ่มต้น: username=admin / password=admin1234');
}

/* ─── seed default company settings ─── */
const DEFAULT_SETTINGS = {
  company_name: 'บริษัท ตัวอย่าง จำกัด',
  company_address: '123 ถนนตัวอย่าง แขวง/ตำบล เขต/อำเภอ จังหวัด 10000',
  company_phone: '02-000-0000',
  company_email: 'billing@example.com',
  company_tax_id: '0000000000000',
  default_tax_rate: '7',
  default_due_days: '30',
  reminder_days_before: '3',
};
const seedSetting = db.prepare('INSERT OR IGNORE INTO settings (key, value) VALUES (?, ?)');
for (const [k, v] of Object.entries(DEFAULT_SETTINGS)) seedSetting.run(k, v);

/* ─────────────────────────────────────────────────────────────
 *  MIDDLEWARE
 * ───────────────────────────────────────────────────────────── */
app.use(express.json({ limit: '2mb' }));
app.use(express.urlencoded({ extended: true }));
app.use(session({
  secret: 'billing-secret-key-2026',
  resave: false,
  saveUninitialized: false,
  cookie: { maxAge: 8 * 3600000 },
}));

function requireAuth(req, res, next) {
  if (req.session && req.session.adminId) return next();
  res.status(401).json({ success: false, message: 'กรุณาเข้าสู่ระบบก่อน' });
}

/* ─────────────────────────────────────────────────────────────
 *  HELPERS
 * ───────────────────────────────────────────────────────────── */
const todayStr = () => new Date().toISOString().slice(0, 10);

function getSettings() {
  const rows = db.prepare('SELECT key, value FROM settings').all();
  return Object.fromEntries(rows.map(r => [r.key, r.value]));
}

function nextCustomerCode() {
  const row = db.prepare("SELECT code FROM customers WHERE code LIKE 'CUST-%' ORDER BY id DESC LIMIT 1").get();
  let n = 1;
  if (row && row.code) n = parseInt(row.code.split('-')[1], 10) + 1;
  return 'CUST-' + String(n).padStart(4, '0');
}

function nextDocNo(prefix) {
  // PREFIX-YYYYMM-#### โดยรันต่อเนื่องภายในเดือน
  const ym = new Date().toISOString().slice(0, 7).replace('-', ''); // YYYYMM
  const like = `${prefix}-${ym}-%`;
  let table, col;
  if (prefix === 'INV') { table = 'invoices'; col = 'invoice_no'; }
  else { table = 'payments'; col = 'receipt_no'; }
  const row = db.prepare(`SELECT ${col} AS no FROM ${table} WHERE ${col} LIKE ? ORDER BY id DESC LIMIT 1`).get(like);
  let n = 1;
  if (row && row.no) n = parseInt(row.no.split('-')[2], 10) + 1;
  return `${prefix}-${ym}-${String(n).padStart(4, '0')}`;
}

// คำนวณยอดรวมของใบวางบิลจากรายการสินค้า
function computeTotals(items, discount, taxRate) {
  const subtotal = items.reduce((s, it) => s + Number(it.quantity) * Number(it.unit_price), 0);
  const disc = Number(discount) || 0;
  const taxable = Math.max(subtotal - disc, 0);
  const taxAmount = +(taxable * (Number(taxRate) || 0) / 100).toFixed(2);
  const total = +(taxable + taxAmount).toFixed(2);
  return { subtotal: +subtotal.toFixed(2), discount: disc, taxAmount, total };
}

// ตัดสินสถานะตามยอดชำระและวันครบกำหนด → pending / paid / overdue
function deriveStatus(inv) {
  if (inv.paid_amount >= inv.total - 0.001 && inv.total > 0) return 'paid';
  if (inv.due_date && inv.due_date < todayStr()) return 'overdue';
  return 'pending';
}

// อัปเดตสถานะใบวางบิลใบเดียว
function refreshInvoiceStatus(id) {
  const inv = db.prepare('SELECT * FROM invoices WHERE id = ?').get(id);
  if (!inv) return;
  const status = deriveStatus(inv);
  db.prepare('UPDATE invoices SET status = ? WHERE id = ?').run(status, id);
}

// อัปเดตสถานะค้างชำระทั้งระบบ (เรียกตอนโหลด dashboard / รายการ)
function refreshAllOverdue() {
  const rows = db.prepare("SELECT * FROM invoices WHERE status != 'paid'").all();
  const upd = db.prepare('UPDATE invoices SET status = ? WHERE id = ?');
  const tx = db.transaction(() => {
    for (const inv of rows) upd.run(deriveStatus(inv), inv.id);
  });
  tx();
}

const STATUS_TH = { pending: 'รอชำระ', paid: 'ชำระแล้ว', overdue: 'ค้างชำระ' };
const fmtMoney = n => Number(n || 0).toLocaleString('th-TH', { minimumFractionDigits: 2, maximumFractionDigits: 2 });

/* ─────────────────────────────────────────────────────────────
 *  EMAIL / SMS (ฟีเจอร์ 7) — ส่งจริงผ่าน SMTP ถ้าตั้งค่า ENV ไว้
 *  ตั้งค่าได้ผ่าน env: SMTP_HOST, SMTP_PORT, SMTP_USER, SMTP_PASS, SMTP_FROM
 *  ถ้าไม่ตั้งค่า → โหมดจำลอง (บันทึก log ไว้ตรวจสอบได้)
 * ───────────────────────────────────────────────────────────── */
let mailer = null;
if (nodemailer && process.env.SMTP_HOST) {
  mailer = nodemailer.createTransport({
    host: process.env.SMTP_HOST,
    port: Number(process.env.SMTP_PORT || 587),
    secure: Number(process.env.SMTP_PORT) === 465,
    auth: process.env.SMTP_USER ? { user: process.env.SMTP_USER, pass: process.env.SMTP_PASS } : undefined,
  });
  console.log('📧 เปิดใช้งานการส่งอีเมลผ่าน SMTP:', process.env.SMTP_HOST);
} else {
  console.log('📧 โหมดจำลองการส่งอีเมล/SMS (ยังไม่ได้ตั้งค่า SMTP_HOST)');
}

async function sendNotification({ invoiceId, channel, docType, recipient, subject, message }) {
  let status = 'simulated';
  let error = null;
  try {
    if (channel === 'email' && mailer) {
      await mailer.sendMail({
        from: process.env.SMTP_FROM || process.env.SMTP_USER || 'billing@example.com',
        to: recipient,
        subject,
        text: message,
        html: `<pre style="font-family:Tahoma,sans-serif;font-size:14px">${message.replace(/</g, '&lt;')}</pre>`,
      });
      status = 'sent';
    } else {
      // SMS หรือ email ที่ยังไม่ได้ตั้งค่า → จำลองการส่ง
      status = 'simulated';
    }
  } catch (e) {
    status = 'failed';
    error = String(e.message || e);
  }
  db.prepare(`INSERT INTO notifications (invoice_id, channel, doc_type, recipient, subject, message, status, error)
              VALUES (?, ?, ?, ?, ?, ?, ?, ?)`)
    .run(invoiceId || null, channel, docType, recipient || '', subject || '', message || '', status, error);
  return { status, error };
}

/* ─────────────────────────────────────────────────────────────
 *  AUTH
 * ───────────────────────────────────────────────────────────── */
app.post('/api/auth/login', (req, res) => {
  const { username, password } = req.body;
  const admin = db.prepare('SELECT * FROM admins WHERE username = ?').get(username);
  if (!admin || !bcrypt.compareSync(password || '', admin.password)) {
    return res.json({ success: false, message: 'ชื่อผู้ใช้หรือรหัสผ่านไม่ถูกต้อง' });
  }
  req.session.adminId = admin.id;
  req.session.adminUsername = admin.username;
  res.json({ success: true, username: admin.username });
});

app.post('/api/auth/logout', (req, res) => {
  req.session.destroy(() => res.json({ success: true }));
});

app.get('/api/auth/me', (req, res) => {
  if (req.session && req.session.adminId) {
    res.json({ loggedIn: true, username: req.session.adminUsername });
  } else {
    res.json({ loggedIn: false });
  }
});

app.post('/api/auth/change-password', requireAuth, (req, res) => {
  const { oldPassword, newPassword } = req.body;
  const admin = db.prepare('SELECT * FROM admins WHERE id = ?').get(req.session.adminId);
  if (!bcrypt.compareSync(oldPassword || '', admin.password)) {
    return res.json({ success: false, message: 'รหัสผ่านเดิมไม่ถูกต้อง' });
  }
  if (!newPassword || newPassword.length < 6) {
    return res.json({ success: false, message: 'รหัสผ่านใหม่ต้องมีอย่างน้อย 6 ตัวอักษร' });
  }
  db.prepare('UPDATE admins SET password = ? WHERE id = ?').run(bcrypt.hashSync(newPassword, 10), req.session.adminId);
  res.json({ success: true, message: 'เปลี่ยนรหัสผ่านสำเร็จ' });
});

/* ─────────────────────────────────────────────────────────────
 *  SETTINGS (ข้อมูลบริษัทสำหรับเอกสาร)
 * ───────────────────────────────────────────────────────────── */
app.get('/api/settings', requireAuth, (req, res) => res.json({ success: true, data: getSettings() }));

app.put('/api/settings', requireAuth, (req, res) => {
  const upd = db.prepare('INSERT INTO settings (key, value) VALUES (?, ?) ON CONFLICT(key) DO UPDATE SET value = excluded.value');
  const tx = db.transaction((obj) => { for (const [k, v] of Object.entries(obj)) upd.run(k, String(v)); });
  tx(req.body || {});
  res.json({ success: true, data: getSettings() });
});

/* ─────────────────────────────────────────────────────────────
 *  CUSTOMERS (ฟีเจอร์ 3)
 * ───────────────────────────────────────────────────────────── */
app.get('/api/customers', requireAuth, (req, res) => {
  const { search = '', page = 1, limit = 50 } = req.query;
  const offset = (page - 1) * limit;
  let where = '';
  const params = [];
  if (search) {
    where = 'WHERE name LIKE ? OR phone LIKE ? OR email LIKE ? OR code LIKE ?';
    const like = `%${search}%`;
    params.push(like, like, like, like);
  }
  const total = db.prepare(`SELECT COUNT(*) c FROM customers ${where}`).get(...params).c;
  const rows = db.prepare(`
    SELECT c.*,
      (SELECT COUNT(*) FROM invoices i WHERE i.customer_id = c.id) AS invoice_count,
      (SELECT COALESCE(SUM(total - paid_amount),0) FROM invoices i WHERE i.customer_id = c.id AND i.status != 'paid') AS outstanding
    FROM customers c ${where} ORDER BY c.id DESC LIMIT ? OFFSET ?
  `).all(...params, Number(limit), Number(offset));
  res.json({ success: true, data: rows, total, page: Number(page) });
});

app.get('/api/customers/:id', requireAuth, (req, res) => {
  const c = db.prepare('SELECT * FROM customers WHERE id = ?').get(req.params.id);
  if (!c) return res.status(404).json({ success: false, message: 'ไม่พบลูกค้า' });
  c.invoices = db.prepare('SELECT * FROM invoices WHERE customer_id = ? ORDER BY id DESC').all(c.id);
  res.json({ success: true, data: c });
});

app.post('/api/customers', requireAuth, (req, res) => {
  const { name, contact_name, phone, email, address, tax_id, note } = req.body;
  if (!name || !name.trim()) return res.json({ success: false, message: 'กรุณากรอกชื่อลูกค้า' });
  const info = db.prepare(`INSERT INTO customers (code, name, contact_name, phone, email, address, tax_id, note)
                           VALUES (?, ?, ?, ?, ?, ?, ?, ?)`)
    .run(nextCustomerCode(), name.trim(), contact_name || '', phone || '', email || '', address || '', tax_id || '', note || '');
  res.json({ success: true, id: info.lastInsertRowid, message: 'เพิ่มลูกค้าสำเร็จ' });
});

app.put('/api/customers/:id', requireAuth, (req, res) => {
  const { name, contact_name, phone, email, address, tax_id, note } = req.body;
  if (!name || !name.trim()) return res.json({ success: false, message: 'กรุณากรอกชื่อลูกค้า' });
  db.prepare(`UPDATE customers SET name=?, contact_name=?, phone=?, email=?, address=?, tax_id=?, note=? WHERE id=?`)
    .run(name.trim(), contact_name || '', phone || '', email || '', address || '', tax_id || '', note || '', req.params.id);
  res.json({ success: true, message: 'แก้ไขข้อมูลลูกค้าสำเร็จ' });
});

app.delete('/api/customers/:id', requireAuth, (req, res) => {
  const cnt = db.prepare('SELECT COUNT(*) c FROM invoices WHERE customer_id = ?').get(req.params.id).c;
  if (cnt > 0) return res.json({ success: false, message: 'ลบไม่ได้ เนื่องจากมีใบวางบิลของลูกค้ารายนี้อยู่' });
  db.prepare('DELETE FROM customers WHERE id = ?').run(req.params.id);
  res.json({ success: true, message: 'ลบลูกค้าสำเร็จ' });
});

/* ─────────────────────────────────────────────────────────────
 *  INVOICES (ฟีเจอร์ 1, 4, 6)
 * ───────────────────────────────────────────────────────────── */
function loadInvoice(id) {
  const inv = db.prepare('SELECT * FROM invoices WHERE id = ?').get(id);
  if (!inv) return null;
  inv.customer = db.prepare('SELECT * FROM customers WHERE id = ?').get(inv.customer_id);
  inv.items = db.prepare('SELECT * FROM invoice_items WHERE invoice_id = ?').all(id);
  inv.payments = db.prepare('SELECT * FROM payments WHERE invoice_id = ? ORDER BY id').all(id);
  inv.status_th = STATUS_TH[inv.status];
  return inv;
}

app.get('/api/invoices', requireAuth, (req, res) => {
  refreshAllOverdue();
  const { search = '', status = '', customer_id = '', from = '', to = '' } = req.query;
  const where = [];
  const params = [];
  if (status) { where.push('i.status = ?'); params.push(status); }
  if (customer_id) { where.push('i.customer_id = ?'); params.push(customer_id); }
  if (from) { where.push('i.issue_date >= ?'); params.push(from); }
  if (to) { where.push('i.issue_date <= ?'); params.push(to); }
  if (search) { where.push('(i.invoice_no LIKE ? OR c.name LIKE ?)'); params.push(`%${search}%`, `%${search}%`); }
  const clause = where.length ? 'WHERE ' + where.join(' AND ') : '';
  const rows = db.prepare(`
    SELECT i.*, c.name AS customer_name, c.email AS customer_email, c.phone AS customer_phone
    FROM invoices i JOIN customers c ON c.id = i.customer_id
    ${clause} ORDER BY i.id DESC
  `).all(...params);
  rows.forEach(r => { r.status_th = STATUS_TH[r.status]; r.outstanding = +(r.total - r.paid_amount).toFixed(2); });
  res.json({ success: true, data: rows });
});

app.get('/api/invoices/:id', requireAuth, (req, res) => {
  refreshInvoiceStatus(req.params.id);
  const inv = loadInvoice(req.params.id);
  if (!inv) return res.status(404).json({ success: false, message: 'ไม่พบใบวางบิล' });
  res.json({ success: true, data: inv });
});

app.post('/api/invoices', requireAuth, (req, res) => {
  const s = getSettings();
  const { customer_id, issue_date, due_date, items = [], discount = 0, tax_rate, note } = req.body;
  if (!customer_id) return res.json({ success: false, message: 'กรุณาเลือกลูกค้า' });
  const cleanItems = items
    .filter(it => it.description && it.description.trim())
    .map(it => ({
      description: it.description.trim(),
      quantity: Number(it.quantity) || 0,
      unit_price: Number(it.unit_price) || 0,
      amount: +((Number(it.quantity) || 0) * (Number(it.unit_price) || 0)).toFixed(2),
    }));
  if (cleanItems.length === 0) return res.json({ success: false, message: 'กรุณาเพิ่มรายการอย่างน้อย 1 รายการ' });

  const issue = issue_date || todayStr();
  const due = due_date || new Date(Date.now() + Number(s.default_due_days || 30) * 86400000).toISOString().slice(0, 10);
  const rate = tax_rate === undefined || tax_rate === '' ? Number(s.default_tax_rate || 0) : Number(tax_rate);
  const t = computeTotals(cleanItems, discount, rate);

  const tx = db.transaction(() => {
    const no = nextDocNo('INV');
    const info = db.prepare(`INSERT INTO invoices
      (invoice_no, customer_id, issue_date, due_date, status, subtotal, discount, tax_rate, tax_amount, total, note)
      VALUES (?, ?, ?, ?, 'pending', ?, ?, ?, ?, ?, ?)`)
      .run(no, customer_id, issue, due, t.subtotal, t.discount, rate, t.taxAmount, t.total, note || '');
    const invId = info.lastInsertRowid;
    const insItem = db.prepare('INSERT INTO invoice_items (invoice_id, description, quantity, unit_price, amount) VALUES (?, ?, ?, ?, ?)');
    for (const it of cleanItems) insItem.run(invId, it.description, it.quantity, it.unit_price, it.amount);
    refreshInvoiceStatus(invId);
    return invId;
  });
  const id = tx();
  res.json({ success: true, id, data: loadInvoice(id), message: 'สร้างใบวางบิลสำเร็จ' });
});

app.put('/api/invoices/:id', requireAuth, (req, res) => {
  const inv = db.prepare('SELECT * FROM invoices WHERE id = ?').get(req.params.id);
  if (!inv) return res.status(404).json({ success: false, message: 'ไม่พบใบวางบิล' });
  if (inv.paid_amount > 0) return res.json({ success: false, message: 'แก้ไขไม่ได้ เนื่องจากมีการชำระเงินบางส่วนแล้ว' });
  const { customer_id, issue_date, due_date, items = [], discount = 0, tax_rate, note } = req.body;
  const cleanItems = items
    .filter(it => it.description && it.description.trim())
    .map(it => ({
      description: it.description.trim(),
      quantity: Number(it.quantity) || 0,
      unit_price: Number(it.unit_price) || 0,
      amount: +((Number(it.quantity) || 0) * (Number(it.unit_price) || 0)).toFixed(2),
    }));
  if (cleanItems.length === 0) return res.json({ success: false, message: 'กรุณาเพิ่มรายการอย่างน้อย 1 รายการ' });
  const rate = Number(tax_rate) || 0;
  const t = computeTotals(cleanItems, discount, rate);
  const tx = db.transaction(() => {
    db.prepare(`UPDATE invoices SET customer_id=?, issue_date=?, due_date=?, subtotal=?, discount=?, tax_rate=?, tax_amount=?, total=?, note=? WHERE id=?`)
      .run(customer_id || inv.customer_id, issue_date || inv.issue_date, due_date || inv.due_date,
           t.subtotal, t.discount, rate, t.taxAmount, t.total, note || '', inv.id);
    db.prepare('DELETE FROM invoice_items WHERE invoice_id = ?').run(inv.id);
    const insItem = db.prepare('INSERT INTO invoice_items (invoice_id, description, quantity, unit_price, amount) VALUES (?, ?, ?, ?, ?)');
    for (const it of cleanItems) insItem.run(inv.id, it.description, it.quantity, it.unit_price, it.amount);
    refreshInvoiceStatus(inv.id);
  });
  tx();
  res.json({ success: true, data: loadInvoice(inv.id), message: 'แก้ไขใบวางบิลสำเร็จ' });
});

app.delete('/api/invoices/:id', requireAuth, (req, res) => {
  db.prepare('DELETE FROM invoices WHERE id = ?').run(req.params.id);
  res.json({ success: true, message: 'ลบใบวางบิลสำเร็จ' });
});

/* ─── บันทึกการชำระเงิน → ออกใบเสร็จอัตโนมัติ (ฟีเจอร์ 2, 4) ─── */
app.post('/api/invoices/:id/pay', requireAuth, (req, res) => {
  const inv = db.prepare('SELECT * FROM invoices WHERE id = ?').get(req.params.id);
  if (!inv) return res.status(404).json({ success: false, message: 'ไม่พบใบวางบิล' });
  const outstanding = +(inv.total - inv.paid_amount).toFixed(2);
  let { amount, method = 'เงินสด', paid_date, note } = req.body;
  amount = amount === undefined || amount === '' ? outstanding : Number(amount);
  if (!(amount > 0)) return res.json({ success: false, message: 'จำนวนเงินไม่ถูกต้อง' });
  if (amount > outstanding + 0.001) return res.json({ success: false, message: `ชำระเกินยอดค้าง (คงเหลือ ${fmtMoney(outstanding)} บาท)` });

  const tx = db.transaction(() => {
    const receiptNo = nextDocNo('REC');
    db.prepare('INSERT INTO payments (receipt_no, invoice_id, amount, method, paid_date, note) VALUES (?, ?, ?, ?, ?, ?)')
      .run(receiptNo, inv.id, amount, method, paid_date || todayStr(), note || '');
    const newPaid = +(inv.paid_amount + amount).toFixed(2);
    const paidAt = newPaid >= inv.total - 0.001 ? new Date().toISOString() : null;
    db.prepare('UPDATE invoices SET paid_amount = ?, paid_at = COALESCE(?, paid_at) WHERE id = ?').run(newPaid, paidAt, inv.id);
    refreshInvoiceStatus(inv.id);
    return receiptNo;
  });
  const receiptNo = tx();
  res.json({ success: true, receipt_no: receiptNo, data: loadInvoice(inv.id), message: 'บันทึกการชำระเงินและออกใบเสร็จสำเร็จ' });
});

/* ─── อัปเดตสถานะค้างชำระทั้งหมด ─── */
app.post('/api/invoices/refresh-overdue', requireAuth, (req, res) => {
  refreshAllOverdue();
  res.json({ success: true });
});

/* ─────────────────────────────────────────────────────────────
 *  SEND DOCUMENT (ฟีเจอร์ 7) — email / sms
 * ───────────────────────────────────────────────────────────── */
function buildDocMessage(inv, docType) {
  const s = getSettings();
  const lines = [];
  if (docType === 'receipt') {
    const pay = inv.payments[inv.payments.length - 1];
    lines.push(`ใบเสร็จรับเงิน เลขที่ ${pay ? pay.receipt_no : ''}`);
  } else if (docType === 'reminder') {
    lines.push(`แจ้งเตือนการชำระเงิน — ใบวางบิล ${inv.invoice_no}`);
  } else {
    lines.push(`ใบวางบิล/ใบแจ้งหนี้ เลขที่ ${inv.invoice_no}`);
  }
  lines.push('');
  lines.push(`เรียน คุณ${inv.customer.name}`);
  lines.push(`จาก: ${s.company_name}`);
  lines.push(`วันที่ออก: ${inv.issue_date}`);
  lines.push(`กำหนดชำระ: ${inv.due_date}`);
  lines.push('');
  lines.push('รายการ:');
  inv.items.forEach((it, i) => lines.push(`  ${i + 1}. ${it.description} x${it.quantity} = ${fmtMoney(it.amount)} บาท`));
  lines.push('');
  lines.push(`ยอดสุทธิ: ${fmtMoney(inv.total)} บาท`);
  lines.push(`ชำระแล้ว: ${fmtMoney(inv.paid_amount)} บาท`);
  lines.push(`คงเหลือ: ${fmtMoney(inv.total - inv.paid_amount)} บาท`);
  lines.push(`สถานะ: ${STATUS_TH[inv.status]}`);
  lines.push('');
  lines.push(`ติดต่อสอบถาม: ${s.company_phone} / ${s.company_email}`);
  return lines.join('\n');
}

app.post('/api/invoices/:id/send', requireAuth, async (req, res) => {
  const inv = loadInvoice(req.params.id);
  if (!inv) return res.status(404).json({ success: false, message: 'ไม่พบใบวางบิล' });
  const { channel = 'email', docType = 'invoice', recipient } = req.body;
  const to = recipient || (channel === 'email' ? inv.customer.email : inv.customer.phone);
  if (!to) return res.json({ success: false, message: channel === 'email' ? 'ลูกค้าไม่มีอีเมล' : 'ลูกค้าไม่มีเบอร์โทร' });

  const subjectMap = {
    invoice: `ใบวางบิล ${inv.invoice_no} จาก ${getSettings().company_name}`,
    receipt: `ใบเสร็จรับเงิน — ใบวางบิล ${inv.invoice_no}`,
    reminder: `[แจ้งเตือน] ครบกำหนดชำระ ใบวางบิล ${inv.invoice_no}`,
  };
  const result = await sendNotification({
    invoiceId: inv.id, channel, docType, recipient: to,
    subject: subjectMap[docType] || subjectMap.invoice,
    message: buildDocMessage(inv, docType),
  });
  const verb = result.status === 'sent' ? 'ส่งสำเร็จ' : result.status === 'simulated' ? 'จำลองการส่ง (ยังไม่ได้ตั้งค่า SMTP)' : 'ส่งไม่สำเร็จ';
  res.json({
    success: result.status !== 'failed',
    status: result.status,
    message: `${channel === 'email' ? 'อีเมล' : 'SMS'} → ${to}: ${verb}`,
    error: result.error,
  });
});

app.get('/api/notifications', requireAuth, (req, res) => {
  const rows = db.prepare(`
    SELECT n.*, i.invoice_no FROM notifications n
    LEFT JOIN invoices i ON i.id = n.invoice_id
    ORDER BY n.id DESC LIMIT 100
  `).all();
  res.json({ success: true, data: rows });
});

/* ─────────────────────────────────────────────────────────────
 *  REMINDERS / DUE TRACKING (ฟีเจอร์ 5)
 * ───────────────────────────────────────────────────────────── */
app.get('/api/reminders/due', requireAuth, (req, res) => {
  refreshAllOverdue();
  const s = getSettings();
  const daysBefore = Number(s.reminder_days_before || 3);
  const soon = new Date(Date.now() + daysBefore * 86400000).toISOString().slice(0, 10);
  const overdue = db.prepare(`
    SELECT i.*, c.name AS customer_name, c.email AS customer_email, c.phone AS customer_phone
    FROM invoices i JOIN customers c ON c.id = i.customer_id
    WHERE i.status = 'overdue' ORDER BY i.due_date ASC
  `).all();
  const dueSoon = db.prepare(`
    SELECT i.*, c.name AS customer_name, c.email AS customer_email, c.phone AS customer_phone
    FROM invoices i JOIN customers c ON c.id = i.customer_id
    WHERE i.status = 'pending' AND i.due_date <= ? AND i.due_date >= ? ORDER BY i.due_date ASC
  `).all(soon, todayStr());
  const tag = r => { r.status_th = STATUS_TH[r.status]; r.outstanding = +(r.total - r.paid_amount).toFixed(2); return r; };
  res.json({ success: true, overdue: overdue.map(tag), dueSoon: dueSoon.map(tag), daysBefore });
});

// ส่งแจ้งเตือนแบบกลุ่ม ไปยังทุกใบที่เกินกำหนด/ใกล้ครบกำหนด
app.post('/api/reminders/send-all', requireAuth, async (req, res) => {
  refreshAllOverdue();
  const { channel = 'email', scope = 'overdue' } = req.body;
  const s = getSettings();
  const daysBefore = Number(s.reminder_days_before || 3);
  const soon = new Date(Date.now() + daysBefore * 86400000).toISOString().slice(0, 10);
  let targets;
  if (scope === 'dueSoon') {
    targets = db.prepare("SELECT id FROM invoices WHERE status='pending' AND due_date <= ? AND due_date >= ?").all(soon, todayStr());
  } else {
    targets = db.prepare("SELECT id FROM invoices WHERE status='overdue'").all();
  }
  let sent = 0, skipped = 0;
  for (const t of targets) {
    const inv = loadInvoice(t.id);
    const to = channel === 'email' ? inv.customer.email : inv.customer.phone;
    if (!to) { skipped++; continue; }
    await sendNotification({
      invoiceId: inv.id, channel, docType: 'reminder',
      recipient: to,
      subject: `[แจ้งเตือน] ครบกำหนดชำระ ใบวางบิล ${inv.invoice_no}`,
      message: buildDocMessage(inv, 'reminder'),
    });
    sent++;
  }
  res.json({ success: true, message: `ส่งแจ้งเตือน ${sent} รายการ${skipped ? ` (ข้าม ${skipped} รายการที่ไม่มีช่องทางติดต่อ)` : ''}`, sent, skipped });
});

/* ─────────────────────────────────────────────────────────────
 *  RECEIPTS LIST (ฟีเจอร์ 2)
 * ───────────────────────────────────────────────────────────── */
app.get('/api/receipts', requireAuth, (req, res) => {
  const rows = db.prepare(`
    SELECT p.*, i.invoice_no, c.name AS customer_name
    FROM payments p
    JOIN invoices i ON i.id = p.invoice_id
    JOIN customers c ON c.id = i.customer_id
    ORDER BY p.id DESC
  `).all();
  res.json({ success: true, data: rows });
});

/* ─────────────────────────────────────────────────────────────
 *  DASHBOARD & REPORTS (ฟีเจอร์ 8)
 * ───────────────────────────────────────────────────────────── */
app.get('/api/dashboard/summary', requireAuth, (req, res) => {
  refreshAllOverdue();
  const today = todayStr();
  const month = today.slice(0, 7);

  const totals = db.prepare(`
    SELECT
      COUNT(*) AS invoice_count,
      COALESCE(SUM(total),0) AS billed_total,
      COALESCE(SUM(paid_amount),0) AS collected_total,
      COALESCE(SUM(total - paid_amount),0) AS outstanding_total
    FROM invoices
  `).get();

  const byStatus = db.prepare("SELECT status, COUNT(*) c, COALESCE(SUM(total - paid_amount),0) amt FROM invoices GROUP BY status").all();
  const statusMap = { pending: { c: 0, amt: 0 }, paid: { c: 0, amt: 0 }, overdue: { c: 0, amt: 0 } };
  byStatus.forEach(r => { statusMap[r.status] = { c: r.c, amt: r.amt }; });

  const todayIncome = db.prepare('SELECT COALESCE(SUM(amount),0) v FROM payments WHERE paid_date = ?').get(today).v;
  const monthIncome = db.prepare("SELECT COALESCE(SUM(amount),0) v FROM payments WHERE substr(paid_date,1,7) = ?").get(month).v;
  const customerCount = db.prepare('SELECT COUNT(*) c FROM customers').get().c;

  res.json({
    success: true,
    data: {
      ...totals,
      status: statusMap,
      today_income: todayIncome,
      month_income: monthIncome,
      customer_count: customerCount,
    },
  });
});

// รายรับ: รายวัน (period=daily, ย้อนหลัง N วัน) หรือ รายเดือน (period=monthly, ย้อนหลัง N เดือน)
app.get('/api/dashboard/revenue', requireAuth, (req, res) => {
  const { period = 'daily', n = 14 } = req.query;
  const N = Math.min(Number(n) || 14, 90);
  const labels = [];
  const out = [];

  if (period === 'monthly') {
    const base = new Date();
    for (let i = N - 1; i >= 0; i--) {
      const d = new Date(base.getFullYear(), base.getMonth() - i, 1);
      const ym = d.toISOString().slice(0, 7);
      labels.push(ym);
      const income = db.prepare("SELECT COALESCE(SUM(amount),0) v FROM payments WHERE substr(paid_date,1,7)=?").get(ym).v;
      const billed = db.prepare("SELECT COALESCE(SUM(total),0) v FROM invoices WHERE substr(issue_date,1,7)=?").get(ym).v;
      out.push({ label: ym, income, billed });
    }
  } else {
    for (let i = N - 1; i >= 0; i--) {
      const d = new Date(Date.now() - i * 86400000).toISOString().slice(0, 10);
      labels.push(d);
      const income = db.prepare("SELECT COALESCE(SUM(amount),0) v FROM payments WHERE paid_date=?").get(d).v;
      const billed = db.prepare("SELECT COALESCE(SUM(total),0) v FROM invoices WHERE issue_date=?").get(d).v;
      out.push({ label: d, income, billed });
    }
  }
  res.json({ success: true, data: out, labels });
});

// อันดับลูกค้าที่มียอดซื้อสูงสุด
app.get('/api/dashboard/top-customers', requireAuth, (req, res) => {
  const rows = db.prepare(`
    SELECT c.id, c.name, COUNT(i.id) AS invoice_count,
           COALESCE(SUM(i.total),0) AS billed,
           COALESCE(SUM(i.paid_amount),0) AS paid
    FROM customers c JOIN invoices i ON i.customer_id = c.id
    GROUP BY c.id ORDER BY billed DESC LIMIT 10
  `).all();
  res.json({ success: true, data: rows });
});

/* ─────────────────────────────────────────────────────────────
 *  STATIC + ROUTES
 * ───────────────────────────────────────────────────────────── */
app.use(express.static(__dirname));
app.get('/', (req, res) => res.sendFile(path.join(__dirname, 'billing.html')));

const PORT = process.env.PORT || 4000;
app.listen(PORT, () => {
  console.log(`\n🧾 ระบบวางบิล & เก็บเงิน ทำงานที่ http://localhost:${PORT}`);
  console.log(`   เข้าสู่ระบบ: username=admin / password=admin1234\n`);
});
